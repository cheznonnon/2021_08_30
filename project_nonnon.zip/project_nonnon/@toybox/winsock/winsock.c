



// Link
//
//	-lwsock32 : Win2000 OK
//	-lws2_32  : Win95 unavailable




#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>


#include <windows.h>
#include <winsock.h>




#define mb( s ) MessageBox( NULL, s, "", 0 )




void
winsock_debug( WSADATA *wsadata )
{

	char str[ 1024 ];


	sprintf
	(
		str,
		"Low Ver %s %d.%d \n"
		"Hi  Ver %s %d.%d \n"
		"Desc.   %s %s    \n"
		"State   %s %s    \n",
		"\t", wsadata->wVersion     & 0x0f, wsadata->wVersion     >> 8,
		"\t", wsadata->wHighVersion & 0x0f, wsadata->wHighVersion >> 8,
		"\t", wsadata->szDescription,
		"\t", wsadata->szSystemStatus
	);

	mb( str );


	return;
}

void
winsock_host_check( char *host )
{

	char str[ 1024 ];

	int i;


	HOSTENT *hostent;
	u_char  *addr;


	if ( 1024 <= strlen( host ) ) { return; }


	strcpy( str, host );


	hostent = gethostbyname( str );
	if ( hostent == NULL ) { return; }

	ZeroMemory( str, 1024 * sizeof(char) );
	sprintf
	(
		str,
		"Name %s %s \n",
		"\t",
		hostent->h_name
	);

	i = 0;
	while( 1 )
	{

		if ( hostent->h_aliases[ i ] != NULL )
		{

			sprintf
			(
				&str[ strlen( str ) ],
				"alias %s %s \n",
				"\t",
				hostent->h_aliases[ i ]
			);

			i++;

		} else {

			break;

		}

	}

	i = 0;
	while( 1 )
	{

		if ( hostent->h_addr_list[ i ] != NULL )
		{

			addr = (u_char*) hostent->h_addr_list[ i ];

			sprintf
			(
				&str[ strlen( str ) ],
				"IP %s %d.%d.%d.%d \n",
				"\t",
				addr[ 0 ], addr[ 1 ], addr[ 2 ], addr[ 3 ]
			);


			i++;

		} else {

			break;

		}

	}

	mb( str );


	return;
}

void
winsock_in_addr_check(void *a)
{

	char str[1024];

	u_char *addr;


	if ( a == NULL ) { return; }


	addr = (u_char*) a;

	sprintf(
		str,
		"IP %s %d.%d.%d.%d \n",
		"\t",
		addr[0], addr[1], addr[2], addr[3]);

	mb(str);


	return;
}

void
winsock_server(void)
{

	char str[1024];

	SOCKET             s, c;
	struct sockaddr    addr;
	struct sockaddr_in *addr_in  = (struct sockaddr_in*) &addr;
	int                addr_size = sizeof(struct sockaddr);
	int                ret;


	s = socket(AF_INET, SOCK_STREAM, 0);


	ZeroMemory( &addr, sizeof(struct sockaddr) );

	addr_in->sin_family      = AF_INET;
	addr_in->sin_port        = htons(2048);
	addr_in->sin_addr.s_addr = htonl(INADDR_ANY);

winsock_in_addr_check(&addr_in->sin_addr.s_addr);

	ret = bind(s, &addr, addr_size);
	if ( ret )
	{
		shutdown(s, SD_BOTH);

		closesocket(s);

		return;
	}

	listen( s, 0 );


	while( 1 )
	{

		ZeroMemory( &addr, sizeof(struct sockaddr) );
		c = accept( s, &addr, &addr_size );

mb( "Server : accept()" );


		if ( c != SOCKET_ERROR )
		{

			ZeroMemory( str, 1024 * sizeof(char) );
			recv( c, str, 1024, 0 );


			if ( str[ 0 ] != 0 )
			{

				mb( str );

				break;
			}

		}
	}

	shutdown( c, SD_BOTH );

	closesocket( c );


	shutdown( s, SD_BOTH );

	closesocket( s );


	return;
}

void
winsock_client(void)
{

	char str[1024];

	SOCKET             s;
	struct sockaddr    addr;
	struct sockaddr_in *addr_in = (struct sockaddr_in*) &addr;
	int                addr_size = sizeof(struct sockaddr);
	struct hostent     *hostent;
	int                ret;


	ZeroMemory( str, 1024 * sizeof(char) );
	gethostname( str, 1024 );
//mb( str );


	hostent = gethostbyname(str);
	if ( hostent == NULL ) { return; }

	if ( hostent->h_addr_list[0] == NULL ) { return; }

	if ( hostent->h_addrtype != AF_INET ) { return; }


	s = socket(AF_INET, SOCK_STREAM, 0);


	ZeroMemory( &addr, sizeof(struct sockaddr) );

	addr_in->sin_family = AF_INET;
	addr_in->sin_port   = htons(2048);

	memcpy(
		&addr_in->sin_addr.s_addr,
		hostent->h_addr_list[0],
		sizeof(struct in_addr) );

winsock_in_addr_check(&addr_in->sin_addr.s_addr);


	ret = connect(s, &addr, addr_size);
	if ( ret )
	{
		shutdown(s, SD_BOTH);

		closesocket(s);

		return;
	}


	ZeroMemory( str, 1024 * sizeof(char) );

	sprintf( str, "Nonnon WinSock Test" );

	send( s, str, 1024, 0 );

mb( "Client : Sent" );


	shutdown( s, SD_BOTH );

	closesocket( s );


	return;
}

int
main( int argc, char *argv[] )
{

	int ret;

	WSADATA wsadata;


	ZeroMemory( &wsadata, sizeof(WSADATA) );

	ret = WSAStartup(MAKEWORD(1,0), &wsadata);
	if ( ret ) { return 0; }


//winsock_debug(&wsadata);

//winsock_host_check("DEFAULT");
//winsock_host_check("LocalHost");

	if ( argc == 1 )
	{
		mb("Server : Start");

		winsock_server();

		mb("Server : End");

	} else {

		mb("Client : Start");

		winsock_client();

		mb("Client : End");
	}


	WSACleanup();


	return 0;
}

