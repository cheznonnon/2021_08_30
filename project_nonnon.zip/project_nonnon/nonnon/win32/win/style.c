// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_STYLE
#define _H_NONNON_WIN32_WIN_STYLE




#include "../sysinfo/version.c"


#include "./_debug.c"




#define n_win_style(   h, s, o ) n_win_style_set( h, s, o, n_posix_false )
#define n_win_exstyle( h, s, o ) n_win_style_set( h, s, o, n_posix_true  )

#define N_WIN_STYLE_NEW 0
#define N_WIN_STYLE_ADD 1
#define N_WIN_STYLE_DEL 2

#define n_win_style_new(   h, s ) n_win_style(   h, s, N_WIN_STYLE_NEW )
#define n_win_style_add(   h, s ) n_win_style(   h, s, N_WIN_STYLE_ADD )
#define n_win_style_del(   h, s ) n_win_style(   h, s, N_WIN_STYLE_DEL )
#define n_win_exstyle_new( h, s ) n_win_exstyle( h, s, N_WIN_STYLE_NEW )
#define n_win_exstyle_add( h, s ) n_win_exstyle( h, s, N_WIN_STYLE_ADD )
#define n_win_exstyle_del( h, s ) n_win_exstyle( h, s, N_WIN_STYLE_DEL )

#define n_win_style_get(   h ) GetWindowLong( h, GWL_STYLE   )
#define n_win_exstyle_get( h ) GetWindowLong( h, GWL_EXSTYLE )

void
n_win_style_set( HWND hwnd, DWORD style, int option, n_posix_bool is_ex )
{

	int gwl = GWL_STYLE;
	if ( is_ex ) { gwl = GWL_EXSTYLE; }


	if ( option == N_WIN_STYLE_ADD )
	{

		style |= GetWindowLong( hwnd, gwl );

	} else
	if ( option == N_WIN_STYLE_DEL )
	{

		// [Mechanism]
		//
		//	             : & : | : ^
		//	#1 : 0-0     : 0 : 0 : 0
		//	#2 : 1-1     : 1 : 1 : 0
		//	#3 : 0-1/1-0 : 0 : 1 : 1
		//
		//	1001 = GetWindowLong()
		//	1000 = style
		//
		//	BINARY :  1000 ^ 1111 = 0111
		//	BINARY : ~1000        = 0111
		//	BINARY :  1001 & 0111 = 0001

		style = GetWindowLong( hwnd, gwl ) & (~style);

	}

	SetWindowLong( hwnd, gwl, style );


	return;
}

n_posix_bool
n_win_style_is_classic( void )
{

	// [Mechanism]
	//
	//	dont't use at WinMain, n_posix_true is always returned
	//	WndProc() is needed

	n_posix_bool ret = n_posix_true;


	// [!] : for compatibility layer

	if ( n_posix_false == n_sysinfo_version_xp_or_later() ) { return ret; }


	HMODULE hmod = LoadLibrary( n_posix_literal( "uxtheme.dll" ) );
	FARPROC func = GetProcAddress( hmod, "IsAppThemed" );

	if ( func )
	{
		if ( func() ) { ret = n_posix_false; } else { ret = n_posix_true; }
	}

	FreeLibrary( hmod );


	return ret;
}

void
n_win_style_dropshadow_onoff( HWND hwnd, n_posix_bool onoff )
{

	// [!] : drop-shadow will not be shown when being turned off in "Performance Option"

	// [Needed] : SetWindowPos() with HWND_TOPMOST : shadow will disappear when resized without this

	// [!] : CS_DROPSHADOW == 0x20000

	if ( onoff )
	{
		SetClassLong( hwnd, GCL_STYLE, GetClassLong( hwnd, GCL_STYLE ) |  0x20000 );
	} else {
		SetClassLong( hwnd, GCL_STYLE, GetClassLong( hwnd, GCL_STYLE ) & ~0x20000 );
	}


	return;
}


#endif // _H_NONNON_WIN32_WIN_STYLE

