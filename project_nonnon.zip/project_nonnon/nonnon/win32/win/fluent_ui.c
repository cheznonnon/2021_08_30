// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_FLUENT_UI
#define _H_NONNON_WIN32_WIN_FLUENT_UI




#include "../../game/progressbar.c"

#include "../../neutral/bmp/detect.c"


#include "./dwm.c"
#include "./rect.c"
#include "./style.c"




#define N_WIN_FLUENT_UI_OVERRIDE ( 2 )




static n_posix_bool n_win_fluent_ui_onoff = n_posix_false;




void
n_win_fluent_ui( void )
{

	if ( n_win_style_is_classic() )
	{
		n_win_fluent_ui_onoff = n_posix_false;
	} else {
		if ( n_sysinfo_version_8_or_later() )
		{
			n_win_fluent_ui_onoff = n_posix_true;
		}
	}


	return;
}

u32
n_win_fluent_ui_accent_color( void )
{

	u32 fg = n_win_dwm_windowcolor();
	u32 bg = n_bmp_lightness_replace_pixel( fg, 111 );


	return bg;
}

s32
n_win_fluent_ui_round_param( void )
{
	return (double) 5 * n_win_scale( NULL );
}

void
n_win_fluent_ui_draw_roundrect( HDC hdc, s32 x, s32 y, s32 sx, s32 sy, int round, COLORREF color, double alpha )
{

	// [!] : this module is heavy : use other solutions instead

	s32 tx = 0;
	s32 ty = 0;
	while( 1 )
	{//break;

		double coeff = 0;
		n_bmp_roundrect_detect_coeff( tx, ty, sx, sy, round, &coeff );

		if ( coeff < 1.0 )
		{
			COLORREF c = GetPixel ( hdc, x + tx, y + ty    );

			c = n_win_color_blend( c, color, coeff * alpha );

			             SetPixelV( hdc, x + tx, y + ty, c );
		} else {
			SetPixelV( hdc, x + tx, y + ty, color );
		}

		tx++;
		if ( tx >= sx )
		{

			tx = 0;

			ty++;
			if ( ty >= sy ) { break; }
		}
	}


	return;
}

void
n_win_fluent_ui_draw_mask( HDC hdc, s32 x, s32 y, s32 sx, s32 sy, int round, COLORREF color )
{

	// [!] : this module is heavy : use other solutions instead

	round += 4;

	s32 tx = 0;
	s32 ty = 0;
	while( 1 )
	{//break;

		double coeff = 0;
		n_bmp_roundrect_detect_coeff( tx, ty, sx, sy, round, &coeff );

		if ( coeff < 1.0 )
		{
			COLORREF c = GetPixel ( hdc, x + tx, y + ty    );

			c = n_win_color_blend( c, color, coeff );

			             SetPixelV( hdc, x + tx, y + ty, c );

			ExcludeClipRect( hdc, x + tx, y + ty, x + tx + 1, y + ty + 1 );
		}

		tx++;
		if ( tx >= sx )
		{

			tx = 0;

			ty++;
			if ( ty >= sy ) { break; }
		}
	}


	return;
}

#define n_win_fluent_ui_bmp_roundframe(        bmp, blur, x,y,sx,sy, bx,by, r,f, fg,bg, msk, blend ) n_win_fluent_ui_bmp_roundframe_main( bmp, blur, x,y,sx,sy, bx,by, r,f, fg,bg, n_posix_true , msk, NULL, blend )
#define n_win_fluent_ui_bmp_roundframe_bitmap( bmp, blur, x,y,sx,sy, bx,by, r,f, fg,bg, msk, blend ) n_win_fluent_ui_bmp_roundframe_main( bmp, blur, x,y,sx,sy, bx,by, r,f, fg,bg, n_posix_false,   0,  msk, blend )

// internal
void
n_win_fluent_ui_bmp_roundframe_main
(
	n_bmp        *bmp,
	n_bmp        *blur,
	s32           x,
	s32           y,
	s32           sx,
	s32           sy,
	s32           blur_x,
	s32           blur_y,
	s32           round_size,
	s32           frame_size,
	u32           color_fg,
	u32           color_bg,
	n_posix_bool  cornermask_onoff,
	u32           cornermask_color,
	n_bmp        *cornermask_bmp,
	double        blend
)
{

	if ( n_bmp_error( bmp  ) ) { return; }
	//if ( n_bmp_error( blur ) ) { return; }

	if ( sx == -1 ) { sx = N_BMP_SX( bmp ); }
	if ( sy == -1 ) { sy = N_BMP_SY( bmp ); }


	if ( cornermask_bmp != NULL )
	{
		n_bmp_flush_fastcopy( cornermask_bmp, bmp );
	} else {
		n_bmp_flush( bmp, cornermask_color );
	}


	s32 m = 0;

	n_bmp_roundrect_main( bmp, blur, x + m, y + m, sx - ( m * 2 ), sy - ( m * 2 ), blur_x,blur_y, color_fg, round_size, 0, blend );

	if ( frame_size )
	{
		m += frame_size;

		double coeff = (double) 0.005 * round_size;
		n_bmp_roundrect_main( bmp, blur, x + m, y + m, sx - ( m * 2 ), sy - ( m * 2 ), blur_x + m,blur_y + m, color_bg, round_size, coeff, blend );
	}


	if ( cornermask_onoff )
	{
		n_bmp_cornermask( bmp, round_size, 0, cornermask_color );
	}


	return;
}

void
n_win_fluent_ui_roundrect_region( HWND hwnd, s32 sx, s32 sy, s32 round )
{

	// [!] : for round rect window
	//
	//	+ use with WS_POPUP window
	//	+ drop shadow is automatically applied by CS_DROPSHADOW
	//	+ for smoother rendering use n_win_fluent_ui_bmp_roundframe()

	int r = round + 1;
	HRGN hrgn = CreateRoundRectRgn( 0,0,sx+1,sy+1, r,r );


	// [Needed] : black screen will intercept

	HDC hdc = GetDC( hwnd );

	FillRgn( hdc, hrgn, GetStockObject( NULL_BRUSH ) );

	ReleaseDC( hwnd, hdc );


	SetWindowRgn( hwnd, hrgn, n_posix_true );

	DeleteObject( hrgn );


	return;
}

void
n_win_fluent_ui_label( HWND hgui, RECT *rect, n_posix_char *fontname, int fontsize )
{

	s32 x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );

	n_posix_char str[ 1024 ];
	n_win_text_get( hgui, str, 1024 );


	COLORREF color_bg = n_win_darkmode_systemcolor( COLOR_WINDOW     );
	COLORREF color_fg = n_win_darkmode_systemcolor( COLOR_WINDOWTEXT );

	HDC hdc = n_gdi_doublebuffer_32bpp_simple_init( hgui, sx,sy );


	if ( n_win_fluent_ui_onoff )
	{
		s32 dpi   = n_win_dpi( hgui );
		s32 round = n_win_fluent_ui_round_param();
		s32 frame = n_win_scale( hgui );

		if ( dpi > 96 ) { frame *= 2; }

		n_win_fluent_ui_bmp_roundframe
		(
			&n_gdi_doublebuffer_32bpp_instance.bmp,
			NULL,
			x,y,sx,sy, 0,0,
			round, frame,
			n_win_darkmode_systemcolor( COLOR_BTNSHADOW ),
			color_bg,
			n_win_darkmode_systemcolor( COLOR_BTNFACE   ),
			1.0
		);
	} else {
		n_win_box( hgui, hdc, rect, color_bg );
		n_win_frame( hdc, x,y,sx,sy, color_fg );
	}


	HFONT   hf = n_win_font_name2hfont( fontname, fontsize );
	LOGFONT lf = n_win_font_hfont2logfont( hf );

	DeleteObject( hf );
	lf.lfQuality = ANTIALIASED_QUALITY;
	hf = n_win_font_logfont2hfont( &lf );

	HFONT hf_2 = SelectObject( hdc, hf );


	SetBkMode   ( hdc, TRANSPARENT );
	SetTextColor( hdc,    color_fg );

	int dt = DT_CENTER | ( DT_SINGLELINE | DT_VCENTER );
	DrawText( hdc, str,-1, rect, dt );


	DeleteObject( SelectObject( hdc, hf_2 ) );


	n_gdi_doublebuffer_32bpp_simple_exit();


	return;
}

void
n_win_fluent_ui_progress( HWND hgui, int percent )
{

	if ( n_posix_false == IsWindow( hgui ) ) { return; }


	n_posix_bool percent_onoff = ( percent >= 0 );


	s32 scale = n_win_scale( hgui );

	n_game_progressbar_solid     = n_posix_true;
	n_game_progressbar_round_div = 4;
	n_game_progressbar_border    = 1 * scale;


	n_game_progressbar_border_color = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNSHADOW );


	u32 bar_fg = n_win_dwm_windowcolor();
	u32 bar_bg = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );

	s32 sx,sy; n_win_size( hgui, &sx, &sy );

	HDC    hdc =  n_gdi_doublebuffer_32bpp_simple_init( hgui, sx, sy );
	n_bmp *bmp = &n_gdi_doublebuffer_32bpp_instance.bmp;

	n_bmp_flush( bmp, bar_bg );

	n_game_progressbar( bmp, 0,0,sx,sy, bar_fg,bar_bg, percent, 1, N_GAME_PROGRESSBAR_HORIZONTAL );


	RECT rect; GetClientRect( hgui, &rect );

	HFONT hf = n_win_font_get( hgui );
	HFONT pf = SelectObject( hdc, hf );

	SetBkMode( hdc, TRANSPARENT );

	n_posix_char str[ 1024 ];

	if ( percent_onoff )
	{
		n_posix_sprintf_literal( str, "%d%%", percent );
	} else {
		n_win_text_get( hgui, str, 1024 );
	}


	int dt = DT_NOPREFIX | DT_NOCLIP | ( DT_SINGLELINE | DT_VCENTER ) | DT_CENTER;

	COLORREF bg;
	COLORREF fg;

	if ( n_win_darkmode_onoff )
	{
		bg = RGB(   0,  0,  0 );
		fg = RGB( 222,222,222 );
	} else {
		bg = RGB( 255,255,255 );
		fg = RGB(   0,  0,  0 );
	}

	SetTextColor( hdc, bg );

	s32 x = -1;
	s32 y = -1;
	while( 1 )
	{
		RECT rect_shadow = rect; n_win_rect_move( &rect_shadow, x,y );
		DrawText( hdc, str, -1, &rect_shadow, dt );

		x++;
		if ( x > 1 )
		{
			x = -1;
			y++;
			if ( y > 1 ) { break; }
		}
	}

	SetTextColor( hdc, fg );
	DrawText( hdc, str, -1, &rect, dt );

	SelectObject( hdc, pf );


	n_gdi_doublebuffer_32bpp_simple_exit();


	return;
}




#endif // _H_NONNON_WIN32_WIN_FLUENT_UI

