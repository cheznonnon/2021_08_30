// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




static HWND n_catpad_keyfocus_hwnd_input  = NULL;
static HWND n_catpad_keyfocus_hwnd_editor = NULL;
static HWND n_catpad_keyfocus_hwnd_txtbox = NULL;




// internal
LRESULT CALLBACK
n_catpad_keyfocus_on_keydown( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	if ( wparam == VK_F3 )
	{

		n_catpad_search( GetParent( hwnd ) );

		return n_true;

	} else
	if ( wparam == VK_RETURN )
	{

		if ( hwnd == n_catpad_keyfocus_hwnd_input )
		{
			if ( n_false == IsWindow( n_catpad_txtbox_search.menu_editbox.hwnd ) )
			{
				n_catpad_search( GetParent( hwnd ) );
				return n_true;
			}
		}

	} else
	if ( ( wparam == 'F' )&&( n_win_is_input( VK_CONTROL ) ) )
	{

		if ( hwnd != n_catpad_keyfocus_hwnd_input )
		{
			n_win_txtbox *p = &n_catpad_txtbox_search;

			// [x] : a caret is drawn badly

			//s32 px  = p->select_cch_x;
			//s32 psx = p->select_cch_sx;

			n_win_txtbox_line_select( p, 0 );

			SetFocus( n_catpad_keyfocus_hwnd_input );

			//p->select_cch_x  = px;
			//p->select_cch_sx = psx;

			p->is_caret_tail = n_true;
		} else {
			n_catpad_focus( hwnd );
		}

		return n_true;

	}


	return n_false;
}

void
n_catpad_keyfocus_init( HWND hwnd_input, HWND hwnd_editor, HWND hwnd_txtbox )
{

	n_catpad_keyfocus_hwnd_input  = hwnd_input;
	n_catpad_keyfocus_hwnd_editor = hwnd_editor;
	n_catpad_keyfocus_hwnd_txtbox = hwnd_txtbox;

#ifdef _WIN64

	SetWindowSubclass( hwnd_input , n_win_subclass_txtbox_on_keydown, 0, (DWORD_PTR) n_catpad_keyfocus_on_keydown );
	SetWindowSubclass( hwnd_editor, n_win_subclass_txtbox_on_keydown, 0, (DWORD_PTR) n_catpad_keyfocus_on_keydown );
	SetWindowSubclass( hwnd_txtbox, n_win_subclass_txtbox_on_keydown, 0, (DWORD_PTR) n_catpad_keyfocus_on_keydown );

#else  // #ifdef _WIN64

	n_win_property_init_literal
	(
		hwnd_input,
		"n_win_subclass_txtbox_on_keydown()",
		(int) n_win_gui_subclass_set( hwnd_input, n_win_subclass_txtbox_on_keydown )
	);

	n_win_property_init_literal
	(
		hwnd_txtbox,
		"n_win_subclass_txtbox_on_keydown()",
		(int) n_win_gui_subclass_set( hwnd_txtbox, n_win_subclass_txtbox_on_keydown )
	);

	n_win_property_init_literal( hwnd_input,  "WM_KEYDOWN", (int) n_catpad_keyfocus_on_keydown );
	n_win_property_init_literal( hwnd_editor, "WM_KEYDOWN", (int) n_catpad_keyfocus_on_keydown );
	n_win_property_init_literal( hwnd_txtbox, "WM_KEYDOWN", (int) n_catpad_keyfocus_on_keydown );

#endif // #ifdef _WIN64


	return;
}

void
n_catpad_keyfocus_exit( HWND hwnd_input, HWND hwnd_editor, HWND hwnd_txtbox )
{

#ifdef _WIN64

	RemoveWindowSubclass( hwnd_input , n_win_subclass_txtbox_on_keydown, 0 );
	RemoveWindowSubclass( hwnd_editor, n_win_subclass_txtbox_on_keydown, 0 );
	RemoveWindowSubclass( hwnd_txtbox, n_win_subclass_txtbox_on_keydown, 0 );

#else  // #ifdef _WIN64

	n_win_property_exit_literal
	(
		hwnd_input,
		"n_win_subclass_txtbox_on_keydown()"
	);

	n_win_property_exit_literal
	(
		hwnd_txtbox,
		"n_win_subclass_txtbox_on_keydown()"
	);

	n_win_property_exit_literal( hwnd_input,  "WM_KEYDOWN" );
	n_win_property_exit_literal( hwnd_editor, "WM_KEYDOWN" );
	n_win_property_exit_literal( hwnd_txtbox, "WM_KEYDOWN" );

#endif // #ifdef _WIN64

	n_catpad_keyfocus_hwnd_input  = NULL;
	n_catpad_keyfocus_hwnd_editor = NULL;
	n_catpad_keyfocus_hwnd_txtbox = NULL;


	return;
}


