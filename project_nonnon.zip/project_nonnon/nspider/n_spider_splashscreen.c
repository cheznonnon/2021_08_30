// Nonnon Spider
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html

// Partial File




void
n_spider_splashscreen( n_spider *p, n_bmp *bmp_target )
{

	n_posix_char *icon_name = n_win_exepath_new();


	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx              = 0;
	gdi.sy              = 0;
	gdi.style           = 0;
	gdi.layout          = N_GDI_LAYOUT_VERTICAL;
	gdi.align           = N_GDI_ALIGN_CENTER;

	gdi.base_color_bg   = p->color_init;
	gdi.base_color_fg   = 0;
	gdi.base_style      = N_GDI_BASE_SOLID;
	gdi.base_unit       = 0;

	gdi.frame_style     = N_GDI_FRAME_NOFRAME;

	gdi.icon            = icon_name;
	gdi.icon_index      = N_GAMECONSOLE_ICON_OFFSET_SPIDER;
	gdi.icon_style      = N_GDI_ICON_RESOURCE;
	gdi.icon_fxsize1    = 0;
	gdi.icon_fxsize2    = 0;

	s32 ctl; n_win_stdsize( game.hwnd, &ctl, NULL, NULL );

	gdi.text            = n_posix_literal( "Nonnon Spider" );
	gdi.text_font       = n_project_stdfont();
	gdi.text_size       = ctl;
	gdi.text_color_main = p->color_text;
	gdi.text_style      = N_GDI_TEXT_SMOOTH;
	gdi.text_fxsize1    = 0;
	gdi.text_fxsize2    = 0;


	n_bmp bmp; n_bmp_zero( &bmp );
	n_gdi_bmp( &gdi, &bmp );
//n_bmp_save_literal( &bmp, "splash.bmp" );

	s32 sx = gdi.sx;
	s32 sy = gdi.sy;
	s32 tx = n_game_centering( game.sx, sx );
	s32 ty = n_game_centering( game.sy, sy );

	n_bmp_flush( bmp_target, p->color_init );
	n_bmp_transcopy( &bmp, bmp_target, 0,0,sx,sy, tx,ty );

	n_bmp_free( &bmp );


	n_string_free( icon_name );


	return;
}



